#include <iostream>

using namespace std;
int main()
{
    cout << "The size of int: " << sizeof(int) << endl;
    cout << "The size of char: " << sizeof(char) << endl;
    cout << "The size of bool: " << sizeof(bool) << endl;
    cout << "The size of short: " << sizeof(short) << endl;
    cout << "The size of long: " << sizeof(long) << endl;
    cout << "The size of unsigned long: " << sizeof(unsigned long) << endl;
    cout << "The size of size_t: " << sizeof(size_t) << endl; //unsigned long
    cout << "The size of float: " << sizeof(float) << endl;
    cout << "The size of double: " << sizeof(double) << endl;

    return 0;
}
        
    

