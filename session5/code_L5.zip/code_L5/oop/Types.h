#ifndef TYPES_H
#define TYPES_H

enum OptionType 
{   
    Call, 
    Put, 
    BinaryCall, 
    BinaryPut
};

#endif
