#ifndef MATH_OPERATIONS_H
#define MATH_OPERATIONS_H

// Function prototypes
int add(int a, int b);
int subtract(int a, int b);
int multiply(int a, int b);

#endif